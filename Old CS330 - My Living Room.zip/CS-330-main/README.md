# CS-330

How do I approach designing software?

How I approached my work on this project was to dedicate certain days to working on it, mainly the sundays of the week as I had the most amount of free time to work on any coding and work I needed to get done. I would tackle the normal assignment of the week first before working on the milestone as when I approach the milestone for that week, I would already know how to work on it much more efficiently and cross reference it if needs be. With this, I was able to knock out these assignments within a few hours without any breaks in between, allowing me more creativity and liberty in my works.

How do I approach developing programs?

I had ended up developing a way of testing when it comes to projects like this. I would create a base few items to work on, experiment with them, and work on any extra fundementals needed before adding in any extra objects or items. This approach helped me immensely as I didn't need to work on adding more than what was needed for the milestone of that week without it being completely empty, focusing on just the treehouse instead of having the entire living room done. If I had worked on the entirety of the living room first, I believe I would've fallen behind badly as I was fairly new to this kind of coding and I would be playing major catchup. Working on learning how to model, create lighting, add in models, scaling, and all of that on just a cabinet and birdhouse allowed me to have some of the scene done AND learn how to create the scene, being effective in the long run.

How can computer science help me in reaching my goals?

With game design being the career I want, computer science will help me immensely as they utilize computers all of the time, ranging from coding to 3d modeling to animation. Having these skills I'm gaining throughout college helps me work on games and become efficient in the studio and not having me be complacent in them. With the knowledge of graphics and visualization and how it works, it will allow me to create visuals for video games that will attract people and not have them gain headaches from them. Having a good looking art style and graphics help the games reception and playability as it allows us to see into the world the game offers. 
