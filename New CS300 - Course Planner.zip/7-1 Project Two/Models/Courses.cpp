#include "Courses.h"
#include <iostream>
#include <algorithm> // for std::sort

class Courses {
public:
    Courses() = default;  // Default constructor

    void Insert(const Course& course) {
        // Insert course into hash table
        coursesHashTable[course.getCourseId()] = course;
    }

    void Remove(const std::string& courseId) {
        // Remove course from hash table if it exists
        auto it = coursesHashTable.find(courseId);
        if (it != coursesHashTable.end()) {
            coursesHashTable.erase(it);
        }
    }

    void PrintCourseList() const {
        // Gather course IDs and sort them
        std::vector<std::string> sortedCourseIds;
        sortedCourseIds.reserve(coursesHashTable.size()); // Reserve space to avoid resizing
        for (const auto& entry : coursesHashTable) {
            sortedCourseIds.push_back(entry.first);
        }

        std::sort(sortedCourseIds.begin(), sortedCourseIds.end());

        std::cout << "Course List:" << std::endl;
        for (const auto& courseId : sortedCourseIds) {
            std::cout << coursesHashTable.at(courseId).courseToString() << std::endl;
        }
    }

    void PrintCourse(const std::string& courseNumber) const {
        auto it = coursesHashTable.find(courseNumber);
        if (it != coursesHashTable.end()) {
            const Course& course = it->second;
            std::cout << "Course Information:" << std::endl;
            std::cout << "Course ID: " << course.getCourseId() << std::endl;
            std::cout << "Course Name: " << course.getCourseName() << std::endl;

            const auto& prerequisites = course.getCoursePrerequisites();
            if (!prerequisites.empty()) {
                std::cout << "Prerequisites: ";
                for (size_t i = 0; i < prerequisites.size(); ++i) {
                    std::cout << prerequisites[i];
                    if (i < prerequisites.size() - 1) {
                        std::cout << ", ";
                    }
                }
            }
            else {
                std::cout << "No Prerequisites";
            }
            std::cout << std::endl;
        }
        else {
            std::cout << "Course not found." << std::endl;
        }
    }

private:
    std::unordered_map<std::string, Course> coursesHashTable;  // Hash table to store courses
};
