#include "Course.h"

Course::Course(const std::string& id, const std::string& name, const std::vector<std::string>& prerequisites)
    : courseId(id), courseName(name), coursePrerequisites(prerequisites) {}

std::string Course::getCourseId() const {
    return courseId;
}

std::string Course::getCourseName() const {
    return courseName;
}

std::vector<std::string> Course::getCoursePrerequisites() const {
    return coursePrerequisites;
}

std::string Course::courseToString() const {
    return courseId + ", " + courseName;
}