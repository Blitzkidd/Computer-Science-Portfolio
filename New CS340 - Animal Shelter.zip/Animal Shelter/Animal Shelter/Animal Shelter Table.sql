﻿CREATE TABLE [dbo].[Animal Shelter Table]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [Age] NCHAR(10) NULL, 
    [Animal_ID] NCHAR(10) NULL, 
    [Animal_Type] NCHAR(10) NULL, 
    [Animal_Breed] NCHAR(100) NULL, 
    [DOB] DATE NULL, 
    [Animal_Name] NCHAR(100) NULL, 
    [Animal_Sex] NCHAR(100) NULL, 
    [Animal_Status] NCHAR(100) NULL
)
